self.addEventListener("push", event => {
  let data={title:"4 Pick Edge",body:"Nueva actualización",url:"/"};
  try { data={...data,...event.data.json()}; } catch(e) {}
  event.waitUntil(self.registration.showNotification(data.title,{
    body:data.body,
    icon:"/icon-192.png",
    badge:"/icon-192.png",
    data:{url:data.url}
  }));
});
self.addEventListener("notificationclick", event => {
  event.notification.close();
  const url=(event.notification.data||{}).url||"/";
  event.waitUntil(clients.matchAll({type:"window",includeUncontrolled:true}).then(list=>{
    for(const c of list){ if("focus" in c){ c.navigate(url); return c.focus(); } }
    return clients.openWindow(url);
  }));
});
